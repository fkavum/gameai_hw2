package com.cin_damasi.app.chinese_checker_package;

class HumanPlayer extends Player
{
    public HumanPlayer(int whichPlayer)
    {
        super(whichPlayer);
        ;
    }

    public Move getMove(GameState state)
    {
        return null;
    }
}