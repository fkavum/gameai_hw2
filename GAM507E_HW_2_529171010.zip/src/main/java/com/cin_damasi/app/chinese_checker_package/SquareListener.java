package com.cin_damasi.app.chinese_checker_package;

interface SquareListener
{
    void squareClicked(int row, int column);
}