package com.cin_damasi.app.chinese_checker_package;

interface PieceListener
{
    void pieceClicked(Piece piece);
}